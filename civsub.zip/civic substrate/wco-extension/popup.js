document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("btn-add-signal").onclick = addSignalFromPage;
  document.getElementById("btn-open-viewer").onclick = openViewer;
  document.getElementById("btn-export-pulse").onclick = exportCivicPulse;
});

async function addSignalFromPage() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    chrome.tabs.sendMessage(tab.id, { type: "REQUEST_SIGNAL_FROM_PAGE" }, (signal) => {
      if (chrome.runtime.lastError || !signal) {
        alert("Couldn't capture signal from this page.");
        window.close();
        return;
      }

      chrome.runtime.sendMessage({ 
        type: "CIVIC_SIGNAL", 
        payload: signal 
      });

      // Nice feedback
      const btn = document.getElementById("btn-add-signal");
      btn.textContent = "✅ Signal Added!";
      setTimeout(() => window.close(), 800);
    });
  } catch (e) {
    alert("Error capturing signal.");
    window.close();
  }
}

async function openViewer() {
  try {
    const res = await fetch(chrome.runtime.getURL("config/substrate-extension-config.json"));
    const cfg = await res.json();

    const urlToOpen = cfg.viewer_url || chrome.runtime.getURL("index.html");
    chrome.tabs.create({ url: urlToOpen });
    window.close();
  } catch (e) {
    // fallback if config file is missing
    chrome.tabs.create({ url: chrome.runtime.getURL("index.html") });
    window.close();
  }
}

async function exportCivicPulse() {
  chrome.storage.local.get({ civicPulse: [] }, (data) => {
    if (data.civicPulse.length === 0) {
      alert("No signals yet!");
      return;
    }

    const blob = new Blob([JSON.stringify(data.civicPulse, null, 2)], { 
      type: "application/json" 
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `civic-pulse-${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    window.close();
  });
}