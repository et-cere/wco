#!/usr/bin/env node

import { ingestFrom } from "../substrate/adapters/ingest/index.js";
import { generateSubstrate } from "../substrate/engine/generative.js";
import fs from "fs";

const args = process.argv.slice(2);
const command = args[0];

async function run() {
  if (command === "ingest") {
    const source = args[1];
    const endpoint = args[2] || null;

    const raw = await ingestFrom(source, { endpoint });
    const generated = generateSubstrate(raw);

    fs.writeFileSync("data/generated.json", JSON.stringify(generated, null, 2));
    console.log("Ingested + generated → data/generated.json");
    return;
  }

  if (command === "link") {
    const raw = JSON.parse(fs.readFileSync("data/generated.json"));
    const generated = generateSubstrate(raw);

    fs.writeFileSync("data/generated.json", JSON.stringify(generated, null, 2));
    console.log("Re-linked substrate.");
    return;
  }

  if (command === "export") {
    console.log("Exporting not implemented yet.");
    return;
  }

  console.log("Commands: ingest <source>, link, export");
}

run();
